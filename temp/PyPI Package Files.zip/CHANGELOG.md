# Changelog

All notable changes to gitrama-mcp are documented here.

Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
Versioning: [Semantic Versioning](https://semver.org/spec/v2.0.0.html)

---

## [1.0.0] — 2026-02-21

### Added

**Git Tools (MCP)**
- `gtr_commit` — AI conventional commit message generation from staged diff
- `gtr_branch` — AI branch name generation from task description
- `gtr_pr` — AI PR title + description from diff and commit history
- `gtr_summarize` — Plain English change summary (file / feature / release scopes)
- `gtr_stream_get` / `gtr_stream_set` — Workflow stream management

**DevOps Recovery Tools (MCP)**
- `gtr_diagnose` — CI/CD failure diagnosis from build logs (11 failure types detected)
- `gtr_fix` — AI code fix generation from diagnosis
- `gtr_deploy_fix` — Applies fix with restore point tag, commits, and pushes
- `gtr_report` — Markdown incident report + Slack summary generation

**AI Providers**
- Mistral (self-hosted on gitrama.io — free, no API key required)
- OpenAI (BYOK — gpt-4o-mini default)
- Anthropic Claude (BYOK — claude-haiku default)

**CI/CD Integrations**
- GitHub Actions reusable workflow (`github-action/gitrama-recovery.yml`)
- GitHub Actions Action definition (`github-action/action.yml`)
- Jenkins Declarative Pipeline, Scripted Pipeline, and Shared Library patterns
- HTTP webhook server (`gitrama-webhook` command) with `/webhook/failure`, `/webhook/github`, `/webhook/jenkins` endpoints

**CLI Commands**
- `gitrama-mcp` — starts MCP server (stdio for Claude Desktop, HTTP for remote agents)
- `gitrama-mcp --setup` — interactive setup wizard
- `gitrama-mcp --check` — validate installation
- `gitrama-mcp --list-tools` — list all MCP tools
- `gitrama-mcp --version` — print version
- `gitrama-webhook` — starts the webhook server

**Config**
- Shared `~/.gitrama/config.json` between CLI and MCP server
- Environment variable overrides for all settings
- Workflow streams: wip / hotfix / review / experiment

**Testing**
- 22 tests across two test suites (test_tools.py, test_devops_tools.py)
- All tests use mocks — no live API keys or services required
