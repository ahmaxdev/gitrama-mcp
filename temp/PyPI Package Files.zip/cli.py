"""
gitrama-mcp CLI entry points

After pip install gitrama-mcp, these commands become available:

  gitrama-mcp            — start the MCP server (stdio transport)
  gitrama-mcp --http     — start the MCP server (HTTP transport)
  gitrama-webhook        — start the webhook server
  gitrama-mcp --setup    — run interactive setup wizard
  gitrama-mcp --check    — validate installation
  gitrama-mcp --version  — print version
"""

import argparse
import asyncio
import sys
from pathlib import Path


def mcp_server_main():
    """Entry point for: gitrama-mcp"""
    parser = argparse.ArgumentParser(
        prog="gitrama-mcp",
        description="Gitrama MCP Server — AI-powered Git tools for Claude Desktop and CI/CD pipelines",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  gitrama-mcp                    Start in stdio mode (for Claude Desktop)
  gitrama-mcp --transport http   Start HTTP server (for remote agents)
  gitrama-mcp --setup            Interactive setup wizard
  gitrama-mcp --check            Validate installation
  gitrama-mcp --version          Show version

Claude Desktop config:
  Add to ~/Library/Application Support/Claude/claude_desktop_config.json:
  {
    "mcpServers": {
      "gitrama": {
        "command": "gitrama-mcp",
        "env": { "GITRAMA_MODEL_PROVIDER": "mistral" }
      }
    }
  }
        """,
    )

    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="Transport type (default: stdio for Claude Desktop)",
    )
    parser.add_argument(
        "--port", type=int, default=8765,
        help="Port for HTTP transport (default: 8765)",
    )
    parser.add_argument(
        "--host", default="0.0.0.0",
        help="Host for HTTP transport (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--setup", action="store_true",
        help="Run interactive setup wizard",
    )
    parser.add_argument(
        "--check", action="store_true",
        help="Validate installation and configuration",
    )
    parser.add_argument(
        "--version", action="store_true",
        help="Print version and exit",
    )
    parser.add_argument(
        "--list-tools", action="store_true",
        help="List all available MCP tools",
    )

    args = parser.parse_args()

    # Version
    if args.version:
        from gitrama_mcp import __version__
        print(f"gitrama-mcp {__version__}")
        sys.exit(0)

    # Setup wizard
    if args.setup:
        _run_setup()
        return

    # Check mode
    if args.check:
        _run_check()
        return

    # List tools
    if args.list_tools:
        _list_tools()
        return

    # Start MCP server
    if args.transport == "stdio":
        _start_stdio()
    else:
        _start_http(args.host, args.port)


def webhook_main():
    """Entry point for: gitrama-webhook"""
    parser = argparse.ArgumentParser(
        prog="gitrama-webhook",
        description="Gitrama Webhook Server — receives CI/CD failure events and runs AI recovery",
    )
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--host", default="0.0.0.0")
    args = parser.parse_args()

    try:
        import uvicorn
        from gitrama_mcp.webhook_server import app
        print(f"🚀 Gitrama Webhook Server starting on {args.host}:{args.port}")
        print("   POST /webhook/failure  — generic failure recovery")
        print("   POST /webhook/github   — GitHub Actions integration")
        print("   POST /webhook/jenkins  — Jenkins integration")
        print("   GET  /health           — liveness check")
        uvicorn.run(app, host=args.host, port=args.port)
    except ImportError:
        print("ERROR: starlette and uvicorn are required for the webhook server.")
        print("Run: pip install gitrama-mcp[webhook]")
        sys.exit(1)


# ─────────────────────────────────────────────
# Internals
# ─────────────────────────────────────────────

def _start_stdio():
    """Start MCP server in stdio mode (for Claude Desktop)."""
    from gitrama_mcp.server import run_stdio
    asyncio.run(run_stdio())


def _start_http(host: str, port: int):
    """Start MCP server in HTTP/SSE mode."""
    print(f"HTTP/SSE transport — coming in Phase 2 (gitrama.io hosted)")
    print(f"For now, use: gitrama-mcp --transport stdio")
    sys.exit(1)


def _run_setup():
    """Run interactive setup wizard."""
    setup_script = Path(__file__).parent.parent.parent / "setup.py"
    if setup_script.exists():
        import subprocess
        subprocess.run([sys.executable, str(setup_script)])
    else:
        # Inline mini-setup when setup.py isn't available
        print("\n🎯 Gitrama MCP Quick Setup\n")
        _quick_setup()


def _quick_setup():
    """Minimal interactive setup when full setup.py isn't available."""
    import json
    from pathlib import Path

    provider = input("AI provider [mistral/openai/claude] (default: mistral): ").strip() or "mistral"
    api_key = None
    if provider in ("openai", "claude"):
        api_key = input(f"{provider.upper()} API key: ").strip()

    stream = input("Default stream [wip/hotfix/review/experiment] (default: wip): ").strip() or "wip"

    config = {"model_provider": provider, "stream": stream}
    if api_key:
        config["api_key"] = api_key

    config_path = Path.home() / ".gitrama" / "config.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\n✅ Config saved to {config_path}")
    print("\nAdd to Claude Desktop config (claude_desktop_config.json):")
    print(json.dumps({
        "mcpServers": {
            "gitrama": {
                "command": "gitrama-mcp",
                "env": {"GITRAMA_MODEL_PROVIDER": provider},
            }
        }
    }, indent=2))


def _run_check():
    """Validate the installation."""
    import subprocess
    print("\n🔍 Gitrama MCP — Installation Check\n")

    checks = [
        ("Python version", lambda: f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"),
        ("gitrama_mcp importable", lambda: __import__("gitrama_mcp").__version__),
        ("mcp importable", lambda: __import__("mcp") and "OK"),
        ("config exists", lambda: (
            "~/.gitrama/config.json"
            if (Path.home() / ".gitrama" / "config.json").exists()
            else "NOT FOUND (run: gitrama-mcp --setup)"
        )),
    ]

    for name, fn in checks:
        try:
            result = fn()
            print(f"  ✅ {name}: {result}")
        except Exception as e:
            print(f"  ❌ {name}: {e}")

    # Run tests
    print()
    test_dir = Path(__file__).parent.parent.parent / "tests"
    if test_dir.exists():
        for test_file in sorted(test_dir.glob("test_*.py")):
            code = subprocess.run(
                [sys.executable, str(test_file)],
                capture_output=True, text=True
            ).returncode
            status = "✅" if code == 0 else "❌"
            print(f"  {status} {test_file.name}")
    print()


def _list_tools():
    """Print all available MCP tools."""
    tools = [
        ("gtr_commit",      "Generate conventional commit message from staged diff"),
        ("gtr_branch",      "Generate branch name from task description"),
        ("gtr_pr",          "Generate PR title and description"),
        ("gtr_summarize",   "Summarize changes in plain English"),
        ("gtr_stream_get",  "Get current workflow stream"),
        ("gtr_stream_set",  "Set workflow stream (wip/hotfix/review/experiment)"),
        ("gtr_diagnose",    "Diagnose CI/CD pipeline failure from build logs"),
        ("gtr_fix",         "Generate code fix for diagnosed failure"),
        ("gtr_report",      "Generate incident report from diagnosis + fix"),
    ]
    print("\n🔧 Available Gitrama MCP Tools\n")
    for name, desc in tools:
        print(f"  {name:<20} {desc}")
    print()
